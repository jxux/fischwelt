const app = new Vue({
  el: '#app',
  data: {
    titulo: 'Corporación FischWelt',
    menu: false,
    // frutas: [
    //   {nombre:'Pera', cantidad:10},
    //   {nombre:'Manzana', cantidad:0},
    //   {nombre:'Platano', cantidad:11}
    // ]
  }
})